-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 14 2019 г., 10:34
-- Версия сервера: 5.6.38
-- Версия PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `catalogL6`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `good_id` int(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL,
  `category` int(3) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(10) DEFAULT NULL,
  `views_count` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`good_id`, `name`, `description`, `category`, `image`, `price`, `views_count`) VALUES
(1, 'Супер платье111', 'Очень красивое платье бла-бла', 1, 'upload/1573723950-dress3.jpg', 2008, 39),
(2, 'Платье 2', 'Еще одно очень красивое платье', 1, 'upload/dress2.jpg', 5000, 34);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int(5) NOT NULL,
  `good_id` int(5) NOT NULL,
  `author` varchar(25) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `good_id`, `author`, `text`, `date`) VALUES
(1, 1, 'Anna', 'I like it. Very nice dress.', '2019-11-13 12:12:08'),
(2, 1, 'Milana', 'I don\'t like the quality of this dress. Its so so...', '2019-11-12 06:00:12'),
(4, 2, 'Mary', 'Good choise ', '2019-11-13 20:00:49'),
(5, 2, 'test', ' hello', '2019-11-14 08:34:03'),
(6, 1, 'IRINA', ' I bought this dress last week. Its so nice', '2019-11-14 08:35:27'),
(7, 2, 'Alisa', ' I can recommend this dress. Its ok', '2019-11-14 08:53:25'),
(8, 2, 'Anna', ' Its one more test', '2019-11-14 08:55:44'),
(9, 1, 'Silver', 'I test it again and again ', '2019-11-14 08:56:15'),
(10, 1, 'Begood', 'A little test ', '2019-11-14 09:32:08');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`good_id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `good_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
