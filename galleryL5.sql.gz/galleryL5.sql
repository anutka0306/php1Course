-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 10 2019 г., 12:19
-- Версия сервера: 5.6.38
-- Версия PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `galleryL5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` int(3) NOT NULL,
  `url` varchar(255) NOT NULL,
  `size` int(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `views` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `url`, `size`, `name`, `views`) VALUES
(6, 'images/1573381045-happy1.jpg', 96860, 'happy1.jpg', 4),
(7, 'images/1573381054-happy2.jpg', 135558, 'happy2.jpg', 1),
(8, 'images/1573381063-happy3.jpg', 39660, 'happy3.jpg', 4),
(10, 'images/1573384571-1572888709-trava-dlia-zhinochoho-zdorov-ia-6-krashchykh-likuvalnykh-retseptiv-1000x600.jpg', 62179, '1572888709-trava-dlia-zhinochoho-zdorov-ia-6-krashchykh-likuvalnykh-retseptiv-1000x600.jpg', 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
